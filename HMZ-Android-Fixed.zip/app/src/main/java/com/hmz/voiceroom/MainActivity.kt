package com.hmz.voiceroom

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0D061A)
private val Panel = Color(0xFF1E1038)
private val Purple = Color(0xFF7C3AED)
private val Lilac = Color(0xFFE9D5FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { HMZApp() } }
    }
}

private data class Room(val id: Int, val title: String, val topic: String, val people: Int)

@Composable
private fun HMZApp() {
    var screen by remember { mutableStateOf("home") }
    var currentRoom by remember { mutableStateOf(Room(1, "جلسة أصدقاء HMZ", "دردشة وألعاب", 3)) }
    var nextId by remember { mutableIntStateOf(4) }
    val rooms = remember { mutableStateListOf(
        Room(1, "جلسة أصدقاء HMZ", "دردشة وألعاب", 3),
        Room(2, "سوالف ليلية", "تعرف على أصدقاء", 5),
        Room(3, "تحدي الأسئلة", "أسئلة وتسلية", 2)
    ) }
    when (screen) {
        "create" -> CreateRoomScreen(
            onBack = { screen = "home" },
            onCreate = { title, topic ->
                val room = Room(nextId++, title, topic, 1)
                rooms.add(0, room)
                currentRoom = room
                screen = "room"
            }
        )
        "room" -> VoiceRoomScreen(room = currentRoom, onBack = { screen = "home" })
        else -> HomeScreen(
            rooms = rooms,
            onCreate = { screen = "create" },
            onOpen = { currentRoom = it; screen = "room" }
        )
    }
}

@Composable
private fun AppScaffold(title: String, back: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(
            Modifier.fillMaxWidth().background(Color(0xFF130924)).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (back != null) {
                IconButton(onClick = back) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
                Spacer(Modifier.width(4.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("غرف صوتية وألعاب · HMZ", color = Lilac, fontSize = 12.sp)
            }
        }
        Column(Modifier.fillMaxSize().padding(16.dp), content = content)
    }
}

@Composable
private fun HomeScreen(rooms: List<Room>, onCreate: () -> Unit, onOpen: (Room) -> Unit) {
    AppScaffold("HMZ") {
        Text("أهلاً بك في HMZ", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("اختر غرفة للدخول أو أنشئ غرفة جديدة.", color = Lilac)
        Spacer(Modifier.height(16.dp))
        Button(onClick = onCreate, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
            Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("إنشاء غرفة")
        }
        Spacer(Modifier.height(18.dp))
        Text("الغرف النشطة", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(rooms) { room ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onOpen(room) },
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(room.title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text(room.topic, color = Lilac)
                        Spacer(Modifier.height(8.dp))
                        Text("${room.people} مستمعين · 8 مقاعد مايك", color = Color(0xFFC084FC), fontSize = 12.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("نسخة تجريبية: الأسماء والغرف محلية على هذا الجهاز.", color = Color(0xFFB8A5D1), fontSize = 11.sp)
    }
}

@Composable
private fun CreateRoomScreen(onBack: () -> Unit, onCreate: (String, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var topic by remember { mutableStateOf("دردشة وألعاب") }
    AppScaffold("إنشاء غرفة", onBack) {
        Text("اسم الغرفة", color = Lilac)
        OutlinedTextField(
            value = title, onValueChange = { title = it },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text("مثلاً: أصدقاء HMZ") },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                focusedBorderColor = Purple, unfocusedBorderColor = Color(0xFF5B3A83),
                cursorColor = Lilac
            )
        )
        Spacer(Modifier.height(14.dp))
        Text("موضوع الغرفة", color = Lilac)
        OutlinedTextField(
            value = topic, onValueChange = { topic = it },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                focusedBorderColor = Purple, unfocusedBorderColor = Color(0xFF5B3A83),
                cursorColor = Lilac
            )
        )
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { onCreate(title.trim().ifBlank { "غرفة HMZ" }, topic.trim().ifBlank { "دردشة وألعاب" }) },
            modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple)
        ) { Text("إنشاء والدخول للغرفة") }
    }
}

@Composable
private fun VoiceRoomScreen(room: Room, onBack: () -> Unit) {
    var muted by remember { mutableStateOf(true) }
    var handRaised by remember { mutableStateOf(false) }
    var showGames by remember { mutableStateOf(false) }
    val names = remember { mutableStateListOf<String?>("مضيف الغرفة", "سارة", "عمر", null, null, null, null, null) }
    AppScaffold(room.title, onBack) {
        Text(room.topic, color = Lilac)
        Spacer(Modifier.height(10.dp))
        Surface(color = Color(0xFF261245), shape = RoundedCornerShape(12.dp)) {
            Text(
                "تنبيه: هذه نسخة تجريبية. مقاعد المايك لا تبث صوتاً لمستخدمين آخرين حتى تتم إضافة خدمة صوت مباشر.",
                color = Lilac, fontSize = 12.sp, modifier = Modifier.padding(12.dp)
            )
        }
        Spacer(Modifier.height(16.dp))
        Text("مقاعد المايك (8)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Spacer(Modifier.height(10.dp))
        for (row in 0..1) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (col in 0..3) {
                    val i = row * 4 + col
                    Column(
                        Modifier.weight(1f).padding(vertical = 4.dp).border(1.dp, Color(0xFF5B3A83), RoundedCornerShape(14.dp))
                            .background(Panel, RoundedCornerShape(14.dp))
                            .clickable { if (names[i] == null) names[i] = "أنت" }
                            .padding(vertical = 12.dp, horizontal = 2.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(Modifier.size(42.dp).background(if (names[i] == null) Color(0xFF2A154E) else Purple, CircleShape), contentAlignment = Alignment.Center) {
                            Text(names[i]?.take(1) ?: "+", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(names[i] ?: "مقعد ${i + 1}", color = Color.White, fontSize = 10.sp, textAlign = TextAlign.Center, maxLines = 1)
                    }
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            FilledIconButton(onClick = { muted = !muted }, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Purple)) {
                Icon(if (muted) Icons.Default.MicOff else Icons.Default.Mic, contentDescription = "تبديل المايك", tint = Color.White)
            }
            TextButton(onClick = { handRaised = !handRaised }) { Text(if (handRaised) "✋ تم رفع اليد" else "رفع اليد", color = Lilac) }
            Button(onClick = { showGames = true }, colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                Icon(Icons.Default.SportsEsports, null); Spacer(Modifier.width(4.dp)); Text("ألعاب")
            }
        }
    }
    if (showGames) GamesDialog(onDismiss = { showGames = false })
}

@Composable
private fun GamesDialog(onDismiss: () -> Unit) {
    var xTurn by remember { mutableStateOf(true) }
    var cells by remember { mutableStateOf(List(9) { "" }) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("لعبة XO التجريبية") },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("لعبة محلية على جهاز واحد", fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                for (r in 0..2) {
                    Row {
                        for (c in 0..2) {
                            val i = r * 3 + c
                            OutlinedButton(
                                onClick = { if (cells[i].isEmpty()) { cells = cells.toMutableList().also { it[i] = if (xTurn) "X" else "O" }; xTurn = !xTurn } },
                                modifier = Modifier.size(58.dp).padding(2.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) { Text(cells[i], fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                }
                TextButton(onClick = { cells = List(9) { "" }; xTurn = true }) { Text("إعادة اللعبة") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("إغلاق") } }
    )
}
